# Fable QUMAT MMC Veb Saytı - YOUWARE İnkişaf Təlimatları

## Layihə Haqqında
Bu layihə "Fable QUMAT MMC" kənd təsərrüfatı şirkəti üçün yaradılmış rəsmi veb saytdır. Sayt organik gübrə məhsulu olan "QUMAT KOMBİ MİX" haqqında məlumat verir və fermerləri maarifləndirmək məqsədi daşıyır.

## Texniki Struktur
- **Ana fayl**: `index.html` - Bütün sayt məzmunu eyni səhifədə yerləşdirilmişdir (single-page application)
- **Dil**: Azərbaycan dili (az)
- **Responsive**: Mobil və masaüstü cihazlar üçün optimallaşdırılmışdır
- **İkonlar**: Font Awesome 6.0.0 istifadə edilir

## Dizayn Rəng Paleti
```css
--primary-green: #2E7D32
--light-green: #4CAF50
--accent-green: #81C784
--earth-brown: #5D4037
--light-brown: #8D6E63
--cream: #F5F5DC
```

## Sayt Bölmələri
1. **Ana Səhifə (#home)** - Hero bölmə və xoş gəlmisiniz mesajı
2. **Məhsullar (#products)** - QUMAT KOMBİ MİX xüsusiyyətləri
3. **Tətbiq Forması (#application)** - İstifadə üsulları və dozalar
4. **Bitkilərə Uyğunluq (#plants)** - Müxtəlif bitkilərdə nəticələr
5. **Maarifləndirmə (#education)** - Fermerlər üçün məqalələr
6. **Videolar (#videos)** - Demo videolar (placeholder)
7. **Rəylər (#reviews)** - Fermer rəyləri (avtomatik dəyişir)
8. **Əlaqə (#contact)** - Əlaqə forması və məlumatları

## Xüsusi Funksionallıq
- **Responsive navigation** - Mobil menyu toggle
- **Smooth scrolling** - Bölmələr arası hamar keçid
- **Scroll animations** - Kartların görünməsi zamanı animasiya
- **Reviews slider** - 5 saniyədə bir rəy dəyişir
- **Contact form** - JavaScript ilə form validasiyası
- **Header scroll effect** - Scroll zamanı header şəffaflığı

## Təkmilləşdirmə İmkanları
1. **Backend İnteqrasiyası**: Əlaqə forması üçün backend xidməti
2. **Real videolar**: Placeholder əvəzinə real video məzmunu
3. **Məqalələr sistemi**: Maarifləndirmə bölməsi üçün CMS
4. **Dil dəstəyi**: Çoxdilli versiyalar (İngiliscə, Türkcə)
5. **SEO optimallaşdırması**: Meta təqləri və struktur data
6. **Performance**: Şəkil optimallaşdırması və lazy loading

## Əlaqə Məlumatları (Demo)
- Telefon: +994 50 590 48 65
- Email: info@fablequmat.com
- WhatsApp: +994 50 590 48 65
- Ünvan: Bakı şəhəri, Azərbaycan

## Browser Dəstəyi
Sayt müasir brauzerlərə optimallaşdırılmışdır (Chrome, Firefox, Safari, Edge).